# Store listing assets

`google-play-feature-graphic-1024x500-CONCEPT.png` is a branded concept graphic that uses the approved KormoKari wordmark and existing screen-preview assets.

**Do not submit it as a final factual screenshot set.** Current Worker/Employer/Inbox images are concept mockups, not captures from a built, tested production app. Before Play Store submission, capture current screens from the actual release candidate and review all store copy, privacy policy, data safety declarations, permissions, and legal requirements.
