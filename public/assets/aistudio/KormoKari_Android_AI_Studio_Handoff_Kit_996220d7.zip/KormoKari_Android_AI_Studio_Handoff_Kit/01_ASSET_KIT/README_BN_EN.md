# KormoKari App Asset Kit

**Design direction:** Connected Opportunity logo + KormoKari premium pink / navy / blue theme.

## Important logo fidelity note
The file in `01-brand/source/connected-opportunity-final-original.png` is the exact selected source artwork provided for this task. The `master` and icon-size PNGs preserve that artwork; edge-connected near-black preview matte pixels are made transparent for the transparent icon variants. The logo is raster artwork, so SVG wrappers embed the raster mark rather than pretending the mark is editable vector paths. Do not redraw or substitute the K symbol without approval.

## Included
- `01-brand/`: untouched source, transparent icon master, horizontal and stacked wordmarks (light/dark), SVG wrappers.
- `02-app-icons/`: standard icon PNGs from 16 to 1024 px.
- `03-pwa/`: PWA icons, maskable variants, Apple touch icon, and a sample `manifest.webmanifest`. Paths in that manifest are examples; update them to match the existing Laravel public asset location before integration.
- `04-favicon/`: PNG sizes plus ICO.
- `05-android-res/`: standard Android launcher mipmap sizes, supporting color/style XML and integration notes. The adaptive foreground PNG is an asset reference, not a complete adaptive icon configuration. Review mask cropping before wiring it into a native Android app.
- `06-theme/`: design tokens JSON, CSS variables and Android color XML.
- `07-ui-icons/`: lightweight line icons for common app navigation and actions.
- `08-illustrations/`: standalone SVG illustrations for onboarding, empty states and success.
- `09-screen-previews/`: illustrative Worker Home, Employer Dashboard and Inbox/Voice mock screens. These are visual design previews, not captures from the running application.
- `10-splash-screens/`: branded splash/startup artwork in common portrait sizes.

## Brand tokens
- Primary magenta: `#E91069`
- Primary dark: `#B90D57`
- Deep navy: `#111827`
- Blue accent: `#3B82F6`
- Surface: `#FFFFFF`
- Background: `#F7F8FC`
- Border: `#E6EAF1`
- Font stack: `Inter, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif`

## Integration safety
This package does not modify the live KormoKari repository. Before using any asset: back up current referenced files, inspect the actual manifest/layout, copy only the needed assets, update references intentionally, and run regression tests. Do not overwrite the app manifest, Android resources or existing logos blindly. Keep existing routes, feature toggles, localization and business logic unchanged.

The sample manifest uses `/assets/app/` paths as illustrative values. Adjust only after reviewing the current project's asset serving conventions. The splash images are static artwork; native Android launch-screen wiring depends on the wrapper project and Android version.
