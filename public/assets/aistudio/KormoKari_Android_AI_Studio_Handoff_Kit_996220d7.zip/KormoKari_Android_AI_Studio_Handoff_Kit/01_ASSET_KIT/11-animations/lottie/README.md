# Lottie splash asset

`kormokari-connected-opportunity-splash.json` references the approved logo image in `images/connected-opportunity-icon-512.png`. Keep the JSON and `images/` directory together so relative paths resolve.

This animation uses an image layer for the approved mark and a lightweight halo. It is an optional source asset; validate it in the exact Lottie runtime used by the app before release. The app does not need Lottie if the CSS/Compose approach is preferred.
