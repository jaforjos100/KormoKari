# Jetpack Compose Brand Reveal Sample

This is an optional post-launch Compose sample, not a complete Android project. Copy the approved logo to `app/src/main/res/drawable-nodpi/kormokari_connected_opportunity.png` and adapt the package/resource identifier to the real app. Requires Compose animation and standard Compose UI dependencies.

Use Android's built-in SplashScreen API for the operating-system launch screen on modern Android. After the first app content is ready, show this brief reveal only if it adds value, and set `appReady=true` when the real route is ready. Do not add a fixed sleep just to display branding. Call `onFinished` to replace the reveal with the actual screen. Ensure lifecycle handling prevents repeated callbacks if the app's state can emit `appReady` more than once.

The sample references `com.kormokari.R`; change only that package reference to match the actual Android package. This snippet was packaged as a starter asset and has not been compiled against the user's Android project.
