package com.kormokari.motion

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Optional native post-launch brand reveal.
 * Add the supplied approved logo at res/drawable-nodpi/kormokari_connected_opportunity.png.
 * Set appReady=true only after the app's actual initial route/data state is ready.
 * This composable does not impose an artificial startup delay.
 */
@Composable
fun KormoKariBrandReveal(
    appReady: Boolean,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var enter by remember { mutableStateOf(false) }
    var hasFinished by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { enter = true }
    val scale by animateFloatAsState(
        targetValue = if (enter) 1f else 0.82f,
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "brandLogoScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (enter) 1f else 0f,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "brandLogoAlpha"
    )
    val contentAlpha by animateFloatAsState(
        targetValue = if (enter) 1f else 0f,
        animationSpec = tween(durationMillis = 650, delayMillis = 120),
        label = "brandContentAlpha"
    )
    LaunchedEffect(appReady, enter, hasFinished) {
        if (appReady && enter && !hasFinished) {
            hasFinished = true
            onFinished()
        }
    }

    Box(
        modifier = modifier.fillMaxSize().background(
            Brush.linearGradient(
                listOf(Color(0xFFFFF8FC), Color(0xFFF7F8FC), Color(0xFFFFF0F7))
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Image(
                painter = painterResource(id = com.kormokari.R.drawable.kormokari_connected_opportunity),
                contentDescription = "KormoKari Connected Opportunity",
                modifier = Modifier.size(184.dp).scale(scale).alpha(alpha),
                contentScale = ContentScale.Fit
            )
            Text(
                text = "KormoKari",
                color = Color(0xFF111827),
                fontSize = 34.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-1.2).sp,
                modifier = Modifier.alpha(contentAlpha)
            )
            Text(
                text = "Find work. Create opportunity.",
                color = Color(0xFF64748B),
                fontSize = 13.sp,
                modifier = Modifier.alpha(contentAlpha)
            )
        }
    }
}
