# KormoKari Animated App Asset Kit — Motion Add-on

This add-on extends the static KormoKari App Asset Kit with **lightweight animated prototypes and integration source**. The chosen Connected Opportunity artwork at `01-brand/master/connected-opportunity-icon-transparent-1254.png` is used as the animation's source image; the logo artwork itself is never redrawn.

## Quick start

1. Open `11-animations/motion-gallery.html` in a modern browser to review Splash, Onboarding, Loading, Voice, Success and Empty-state motion.
2. Open `11-animations/web/splash-screen-demo.html` for the focused splash preview.
3. Use `11-animations/web/kormokari-motion.css` as the reusable motion stylesheet; copy only the classes you need after reviewing the existing app's style system.
4. Review `11-animations/android-compose/KormoKariBrandReveal.kt` and its README if the native wrapper uses Jetpack Compose.
5. `11-animations/lottie/kormokari-connected-opportunity-splash.json` is an optional Lottie image-layer animation. Its approved logo image is in `11-animations/lottie/images/`.
6. `11-animations/preview/animated-splash-preview.gif` shows a looping visual preview; it is a preview asset, not a runtime implementation.

## Where to animate

- **Splash / first brand reveal:** logo scale-and-fade, soft ambient glow, restrained node orbit, wordmark entrance and three-dot progress. Dismiss when the real app is ready; do not add an arbitrary wait to startup.
- **Onboarding:** small illustration float, progressive slide indicators and button feedback.
- **Loading:** shimmer/skeleton only while data is loading.
- **Inbox / voice:** compact waveform bars and recording-state indicator. Real audio playback/recording must be wired to the existing functional chat APIs, not simulated by the gallery.
- **Success:** short checkmark entrance after server-confirmed success.
- **Empty states:** gentle illustration movement; no decorative animation when `prefers-reduced-motion` is enabled.
- **Buttons and cards:** short transform/opacity feedback only; avoid motion that delays tasks.

## Important platform notes

- The included HTML/CSS demos are prototypes and can be opened offline from the extracted ZIP.
- CSS animations use mostly transforms and opacity and include a `prefers-reduced-motion: reduce` fallback.
- On modern Android, the operating-system launch splash is controlled by Android's SplashScreen API and should be brief. Use the animated brand-reveal screen as app content after the system splash if a native wrapper is present.
- For a TWA/PWA wrapper, ensure the site loads over HTTPS and wire the animation into the existing app shell only after checking the current routes and service worker. The splash must not block navigation or wait for an artificial timer after real startup is complete.
- Lottie support requires a compatible Lottie runtime. The JSON and image path have been packaged together, but runtime rendering must be checked in the actual app before release.
- No source project, live website, manifest or APK has been modified by this asset package.

## Motion design tokens

- Main magenta: `#E91069`
- Deep navy: `#111827`
- Blue connection accent: `#3B82F6`
- Easing: `cubic-bezier(.22, 1, .36, 1)`
- Preferred entrance duration: roughly 450–850 ms
- Success feedback: roughly 350–550 ms
- Avoid looping movement for important content or long waits

## Integration checklist

- [ ] Confirm the actual Android wrapper: TWA, WebView, native or Compose.
- [ ] Preserve existing logo, color tokens, routes and feature toggles.
- [ ] Use the CSS classes or native equivalent from this package without duplicating app-wide CSS rules.
- [ ] Dismiss the animated reveal as soon as the real app is ready.
- [ ] Honor reduced-motion preferences.
- [ ] Test low-end Android devices, battery usage and app resume behavior.
- [ ] Verify keyboard/focus navigation and screen-reader labels.
- [ ] Run existing UI and messaging regression tests.
- [ ] Remove demo-only content and buttons from production.
