# Native Android resource drop-in (review before copying)

This is a reviewed starting point, not a complete Android app. Copy resources into the active app module only after inspecting its existing `applicationId`, resource naming, themes and launcher configuration.

- `res/mipmap-anydpi-v26/ic_launcher.xml` and `ic_launcher_round.xml`: Android adaptive icon XML for API 26+.
- `res/drawable/ic_launcher_background.xml`: branded gradient background.
- `res/drawable-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher_foreground.png`: density-scaled transparent extraction of the approved Connected Opportunity mark, placed within the central adaptive-icon safe area. The 432×432 px master is retained under `source/`. The complete unmodified approved art remains in `01_ASSET_KIT/01-brand/source/`.
- `res/values/colors.xml`: brand token examples; merge with existing values instead of blindly replacing them.

Before integration, preview the launcher icon on round, squircle and legacy masks. Confirm that the active manifest references `@mipmap/ic_launcher` and that no existing icon resources are overwritten without backup. Do not put signing credentials in this package.
