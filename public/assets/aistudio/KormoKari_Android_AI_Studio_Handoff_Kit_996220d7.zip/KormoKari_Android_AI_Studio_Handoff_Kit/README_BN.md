# KormoKari Android AI Studio Handoff Kit

এই নতুন প্যাকেজটি আগের Animated App Asset Kit-এর ওপর তৈরি করা হয়েছে এবং Android app তৈরির জন্য implementation phase, API mapping template, release checklist, security rules ও adaptive launcher icon resource starter যোগ করা হয়েছে। নির্বাচিত Connected Opportunity artwork source ফাইল হিসেবে সংরক্ষিত আছে।

**এই ZIP একা APK/AAB নয়।** এটিকে সর্বশেষ sanitized KormoKari source ZIP-এর সঙ্গে AI Studio-তে attach করে `00_START_HERE/PHASE_ANDROID_APP_FULL_IMPLEMENTATION.md`-এর prompt ব্যবহার করতে হবে।

## ফোল্ডার
- `00_START_HERE/` — AI Studio-র জন্য copy-paste phase, setup guide, API mapping ও QA checklist
- `01_ASSET_KIT/` — original logo, app/PWA/favicon assets, design tokens, motion files, screen previews
- `02_ANDROID_NATIVE_DROP_IN/` — adaptive icon XML, density-scaled transparent foreground resource variants, background gradient and color tokens (review before copying)
- `03_STORE_LISTING/` — Play Store listing feature graphic concept; actual screenshots must be generated from the built app

No live website/app source was modified. No signing secret or backend credential is included intentionally.
