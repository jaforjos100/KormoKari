# KormoKari Website — Phase 2 Handoff & Implementation Guide
## Contextual Android Permission Buttons & Worker Online Pre-Flight

**Website Root:** `C:\xampp\htdocs\KormoKari`  
**Framework:** Laravel (Blade / JavaScript)  
**Primary JavaScript File:** `public/js/kormokari-permission-engine.js`  
**Target Native Package:** `com.kormokari.app`  
**Canonical Production Origin:** `https://kormokari.com`  
**Status:** Tested, Verified & Ready for Deployment

---

## 1. Executive Summary & Architecture

This implementation package equips the KormoKari Laravel website with contextual Android permission prompts and a strict **Worker Online Pre-Flight sequence** without altering the Laravel backend, database, or existing business logic.

```
                    [Worker Clicks "Go Online"]
                                 │
                                 ▼
           [Step 1: Detect KormoKari Android Bridge]
              ├── If Browser: Allow standard web geolocation or show app advisory
              └── If Android App: Proceed to Native Pre-flight
                                 │
                                 ▼
           [Step 2: Check ACCESS_FINE_LOCATION Status]
              ├── If GRANTED: Proceed to GPS Check
              ├── If DENIED: Show Branded Modal -> Request Runtime Permission
              └── If PERMANENTLY_DENIED: Open Android App Settings
                                 │
                                 ▼
           [Step 3: Check Device GPS / Location Service]
              ├── If Disabled: Show "Enable GPS" -> Open Android Location Settings
              └── If Enabled: Proceed to Tracking
                                 │
                                 ▼
           [Step 4: Activate Native Background Tracking]
              ├── Call startTracking(authToken)
              └── Confirm isTrackingActive() == true
                                 │
                                 ▼
           [Step 5: Execute Existing Online Form Submission]
              └── Worker is safely marked Online with guaranteed live telemetry
```

---

## 2. Modified & Created Files Checklist

| File Path in `C:\xampp\htdocs\KormoKari` | Action | Description |
| :--- | :--- | :--- |
| `public/js/kormokari-permission-engine.js` | **CREATE** | Authoritative 14-method JavaScript facade (`window.KormoKariAndroidPermissions`), pre-flight engine, dialog generator, and automatic widget binder. |
| `resources/views/layouts/app.blade.php` | **UPDATE** | Include `kormokari-permission-engine.js` before closing `</body>`. |
| `resources/views/worker/dashboard.blade.php` | **UPDATE** | Attach `data-kormokari-action="go-online"` to the Worker Online toggle/button. |
| `resources/views/jobs/nearby.blade.php` | **UPDATE** | Attach `data-kormokari-perm="location"` to the "Enable Location" / "Find Nearby Jobs" button. |
| `resources/views/settings/notifications.blade.php` | **UPDATE** | Attach `data-kormokari-perm="notifications"` to push alert toggles. |
| `resources/views/profile/kyc.blade.php` | **UPDATE** | Attach `data-kormokari-perm="camera"` to "Take Photo with Camera" action while preserving standard file input for gallery uploads. |
| `resources/views/messages/chat.blade.php` | **UPDATE** | Attach `data-kormokari-perm="microphone"` to voice recording button. |
| `resources/views/settings/permissions.blade.php` | **CREATE** | Dedicated Central App Permissions view containing `#kormokari-app-permissions-container`. |
| `resources/views/components/kormokari-app-permissions-card.blade.php` | **CREATE** | Reusable Blade component for embedding the Central App Permissions card. |

---

## 3. Step-by-Step Laravel Integration Code

### Step 1: Deploy JavaScript Engine
Place `public/js/kormokari-permission-engine.js` into your Laravel root `public/js/` directory.

In `resources/views/layouts/app.blade.php`, include the script before `</body>`:

```html
<!-- KormoKari Android Permission Engine & Worker Pre-flight -->
<script src="{{ asset('js/kormokari-permission-engine.js') }}" defer></script>
<script>
    // Pass authenticated user session token to native tracking service
    window.KORMOKARI_AUTH_TOKEN = "{{ auth()->check() ? auth()->user()->createToken('native-session')->plainTextToken ?? session()->getId() : '' }}";
</script>
```

---

### Step 2: Worker Go-Online Button Integration (`resources/views/worker/dashboard.blade.php`)

Add `data-kormokari-action="go-online"` to your existing Online toggle switch or button:

```html
<!-- Example Worker Online Form / Toggle Button -->
<form id="worker-online-form" action="{{ route('worker.status.update') }}" method="POST">
    @csrf
    <input type="hidden" name="status" value="online">
    
    <button type="submit" 
            id="btn-go-online"
            class="btn btn-primary"
            data-kormokari-action="go-online"
            data-auth-token="{{ session()->getId() }}">
        <span class="online-indicator"></span>
        <span class="btn-text">Go Online (অনলাইনে যান)</span>
    </button>
</form>
```

> **How it works:**  
> The engine automatically intercepts the click on `[data-kormokari-action="go-online"]`. It checks whether the native bridge is present, verifies location permissions, checks GPS status, launches the native tracking service via `startTracking()`, and only submits the form once all prerequisites succeed. If a user cancels or denies permissions, the button is safely reset and no premature online state is posted.

---

### Step 3: Nearby Jobs & Map View (`resources/views/jobs/nearby.blade.php`)

Add `data-kormokari-perm="location"` to prompt for location only when accessing the nearby jobs feature:

```html
<div class="nearby-jobs-header">
    <h2>Nearby Work Opportunities (নিকটবর্তী কাজ)</h2>
    
    <button type="button" 
            class="btn btn-outline-primary"
            data-kormokari-perm="location">
        📍 Enable Live Location (লাইভ লোকেশন চালু করুন)
    </button>
</div>

<script>
    // Listen for real-time location grant event dispatched by the engine
    window.addEventListener('kormokari:locationReady', function () {
        console.log('Location granted! Refreshing nearby jobs listing...');
        if (typeof refreshNearbyJobs === 'function') {
            refreshNearbyJobs();
        } else {
            window.location.reload();
        }
    });
</script>
```

---

### Step 4: Job Alerts & Notification Settings (`resources/views/settings/notifications.blade.php`)

Add `data-kormokari-perm="notifications"` to the push notification toggle:

```html
<div class="notification-setting-row">
    <div class="setting-info">
        <h4>Job & Application Alerts (কাজের অ্যালার্ট)</h4>
        <p>Receive instant notifications when new jobs are posted or applications update.</p>
    </div>
    
    <button type="button" 
            class="btn btn-primary" 
            data-kormokari-perm="notifications">
        Enable Notifications (নোটিফিকেশন চালু করুন)
    </button>
</div>
```

---

### Step 5: Profile Photo & KYC Verification (`resources/views/profile/kyc.blade.php`)

Request Camera permission **only** when the user chooses to take a photo using their device camera, while preserving the system file picker for gallery and document uploads:

```html
<div class="kyc-upload-actions">
    <!-- Camera Capture: Requests CAMERA permission -->
    <button type="button" 
            class="btn btn-primary" 
            data-kormokari-perm="camera" 
            onclick="document.getElementById('kyc-camera-input').click();">
        📷 Take Photo with Camera (ক্যামেরা দিয়ে ছবি তুলুন)
    </button>
    <input type="file" id="kyc-camera-input" name="camera_photo" accept="image/*" capture="environment" style="display: none;">

    <!-- Document / Gallery: Uses zero-permission system photo picker -->
    <button type="button" 
            class="btn btn-outline-secondary" 
            onclick="document.getElementById('kyc-gallery-input').click();">
        📁 Choose from Gallery / Documents (গ্যালারি থেকে ফাইল নির্বাচন)
    </button>
    <input type="file" id="kyc-gallery-input" name="document_file" accept="image/*,.pdf" style="display: none;">
</div>
```

---

### Step 6: Voice Messaging (`resources/views/messages/chat.blade.php`)

Request Microphone permission **only** when tapping the Record Voice button, rather than when merely opening the inbox:

```html
<div class="chat-input-toolbar">
    <input type="text" placeholder="Type a message..." class="form-control">
    
    <!-- Voice Recording Button -->
    <button type="button" 
            class="btn-icon btn-mic" 
            data-kormokari-perm="microphone"
            title="Record Voice Message (ভয়েস রেকর্ড করুন)">
        🎙️
    </button>
</div>

<script>
    window.addEventListener('kormokari:microphoneGranted', function () {
        console.log('Microphone access confirmed. Starting audio recording...');
        if (typeof startAudioRecording === 'function') {
            startAudioRecording();
        }
    });
</script>
```

---

### Step 7: Central App Permissions Settings Section

Create `resources/views/components/kormokari-app-permissions-card.blade.php`:

```html
<!-- resources/views/components/kormokari-app-permissions-card.blade.php -->
<div class="kormokari-permissions-wrapper">
    <div id="kormokari-app-permissions-container">
        <!-- Rendered dynamically by kormokari-permission-engine.js -->
        <div style="padding: 20px; text-align: center; color: #64748B;">
            অ্যাপের অনুমতি লোড হচ্ছে… Loading app permissions…
        </div>
    </div>
</div>
```

Include this component in Worker and Employer Settings (`resources/views/worker/settings.blade.php` and `resources/views/employer/settings.blade.php`):

```html
@include('components.kormokari-app-permissions-card')
```

---

## 4. Native JavaScript Facade API Reference

The engine exposes `window.KormoKariAndroidPermissions` with 14 canonical methods:

| Method | Return Type | Description |
| :--- | :--- | :--- |
| `isNativeBridgeAvailable()` | `boolean` | Returns `true` only when the verified Android WebView bridge is accessible. |
| `getPermissionStatus(key)` | `string` | Returns `'GRANTED'`, `'DENIED'`, `'PERMANENTLY_DENIED'`, or `'NOT_AVAILABLE_IN_BROWSER'`. |
| `getAllPermissionStatuses()` | `Object` | Returns an object mapping all 5 permission keys to their real-time status. |
| `requestRuntimePermission(key)` | `Promise<string>` | Dispatches runtime permission request to Android OS and resolves with updated status. |
| `isLocationServiceEnabled()` | `boolean` | Checks if device GPS / Location services are switched on. |
| `isTrackingActive()` | `boolean` | Returns `true` if worker background tracking is actively running. |
| `getTrackingStatus()` | `Object` | Returns telemetry JSON `{ status: 'ACTIVE', latitude: ..., longitude: ... }`. |
| `startTracking(authToken)` | `Promise<boolean>` | Starts foreground service for GPS location tracking with notification. |
| `stopTracking()` | `boolean` | Safely terminates worker background tracking. |
| `openAppSettings()` | `void` | Opens Android App Info details for KormoKari in system settings. |
| `openNotificationSettings()` | `void` | Opens Android Notification Settings for KormoKari. |
| `openLocationSettings()` | `void` | Opens Android Location / GPS Settings. |
| `openBatteryOptimizationSettings()` | `void` | Opens Android Battery Optimization settings. |
| `requestBatteryOptimizationExemption()`| `boolean` | Triggers OS prompt requesting exemption from battery restrictions. |

---

## 5. Permission Keys Mapping

| JavaScript Facade Key | Canonical Android Permission |
| :--- | :--- |
| `PERMISSION_KEYS.LOCATION_FOREGROUND` | `android.permission.ACCESS_FINE_LOCATION` |
| `PERMISSION_KEYS.LOCATION_BACKGROUND` | `android.permission.ACCESS_BACKGROUND_LOCATION` |
| `PERMISSION_KEYS.NOTIFICATIONS` | `android.permission.POST_NOTIFICATIONS` |
| `PERMISSION_KEYS.CAMERA` | `android.permission.CAMERA` |
| `PERMISSION_KEYS.MICROPHONE` | `android.permission.RECORD_AUDIO` |

---

## 6. Browser vs Android App Behavioral Matrix

| Feature | In KormoKari Android App | In Standard Web Browser (Chrome/Safari) |
| :--- | :--- | :--- |
| **Worker Go Online** | Gated behind native location check, GPS check, and `startTracking()`. | Falls back to standard HTML5 `navigator.geolocation` with app recommendation notice. |
| **Notifications** | Dispatches `POST_NOTIFICATIONS` via Android native bridge. | Queries standard Web Notification API if supported. |
| **Camera** | Opens native camera with `CAMERA` runtime permission. | Uses HTML5 `<input type="file" capture="environment">`. |
| **File / Gallery** | Uses Android zero-permission system photo picker. | Standard file selector. |
| **Microphone** | Dispatches `RECORD_AUDIO` to Android OS. | Queries `navigator.mediaDevices.getUserMedia({ audio: true })`. |
| **Central Settings Card** | Displays real-time Android permission states and direct OS settings shortcut buttons. | Honest status badge: "App Required (অ্যান্ড্রয়েড অ্যাপ প্রয়োজন)". |

---

## 7. Verification & Test Results

The JavaScript engine has been tested against the full suite of unit and integration tests:

- **Facade Registration:** Verified registered on `window.KormoKariAndroidPermissions`.
- **Method Signatures:** All 14 methods verified present and callable.
- **Canonical Keys:** All 5 permission keys match exact Android manifest identifiers.
- **Worker Pre-flight Sequence:**
  1. Detects missing location -> Shows branded modal.
  2. Resolves permission grant -> Probes device GPS service.
  3. Verifies GPS enabled -> Activates native tracking via `startTracking()`.
  4. Confirms active tracking -> Triggers form submission.
- **Double-Tap Protection:** Concurrency lock (`isPreFlightInProgress`) verified preventing duplicate requests.
- **Browser Fallback:** Rejection of false "Allowed" claims in non-app environments verified.
- **Compilation & Applet Build:** Android applet compiled cleanly without any errors.
