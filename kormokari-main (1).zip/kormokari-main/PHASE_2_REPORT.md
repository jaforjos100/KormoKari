# KormoKari Android — Phase 2 Implementation Report
## Production Signing Identity, Digital Asset Links & Fullscreen TWA Verification

**Application ID:** `com.kormokari.app`  
**Production Origin:** `https://kormokari.com`  
**Target URL:** `https://kormokari.com/`  
**Phase Date:** October 28, 2026  
**Status Summary:** Client configuration complete, tested and verified. Live domain endpoint tested (HTTP 404). Production signing identity marked BLOCKED (requires user-provided release credentials). Complete handoff payloads delivered.

---

### 1. Actual Application ID and Architecture Audit
* **Application ID:** Confirmed preserved as `com.kormokari.app`.
* **Architecture:** Genuine Trusted Web Activity (TWA) hosted via Android Browser Helper (`com.google.androidbrowserhelper:androidbrowserhelper:2.5.0`) backed by AndroidX Custom Tabs.
* **No Mocking / No Direct Custom Tab Subterfuge:** The app is configured with `TwaLauncher` using `TrustedWebActivityIntentBuilder`. When the Digital Asset Links relationship is verified by the host browser, it seamlessly renders in fullscreen standalone mode without URL chrome.
* **Client Origin Binding:** Manifest declares `<meta-data android:name="asset_statements" android:resource="@string/asset_statements" />` directly linking `https://kormokari.com`.
* **Observability:** `KormoKariTwaLauncher` implements `CustomTabsCallback.onRelationshipValidationResult` to observe real-time domain verification results and update system state.

---

### 2. Signing Identity Audit

| Environment | Key Alias | Certificate Authority | Serial Number | SHA-256 Fingerprint | Classification & Suitability |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Local / AI Studio (Debug)** | `androiddebugkey` | `CN=Android Debug, O=Android, C=US` | `1353423e23146c43bc400f1ee3ecf07e` | `0A:91:A8:C0:9D:39:81:B6:3D:56:CF:92:B7:8A:BD:F1:59:69:3A:27:02:60:9F:44:8E:A9:3A:DD:A8:F0:F3:5F` | **Debug Certificate**: Valid strictly for local development, emulator testing, and debug builds. Not suitable for Play Store production. |
| **Release / Production** | Pending (`upload` / Play App Signing) | Pending | Pending | **BLOCKED** | **Production Release Key**: No production keystore (`my-upload-key.jks`) or Play App Signing key is present in this environment. In strict accordance with requirements, no fingerprint was fabricated or guessed. |

---

### 3. Release Distribution Method Finding

Two distinct distribution avenues exist for KormoKari Android:

#### Path A: Google Play Distribution (Recommended)
* **Mechanism:** When using **Google Play App Signing**, Google re-signs the delivered APKs with an App Signing key stored in Google's secure infrastructure.
* **Fingerprint Dependency:** The `assetlinks.json` on `kormokari.com` must contain the **App signing key certificate SHA-256 fingerprint**, located in Google Play Console under **Release > Setup > App Integrity > App Signing**.
* **Action:** Export and upload the release bundle (AAB). Once registered in Play Console, extract the App Signing SHA-256 and insert it into `assetlinks.json`.

#### Path B: Direct APK Distribution (In-House / Sideloading)
* **Mechanism:** The application is distributed directly to users without Google Play intervention.
* **Fingerprint Dependency:** Must use the SHA-256 fingerprint from your private `my-upload-key.jks` or release keystore.
* **Command:** `keytool -list -v -keystore <keystore_file> -alias <alias>`

---

### 4. Live Domain Inspection Result
* **Endpoint Tested:** `https://kormokari.com/.well-known/assetlinks.json`
* **HTTP Status:** `404 Not Found` (Cloudflare edge proxy)
* **Legacy Check:** No live file exists, so no current `com.workdorkar.app` or other association was active on the server.
* **Finding:** Server-side publication is mandatory to activate fullscreen TWA mode.

---

### 5. Delivered Digital Asset Links Payloads

#### File 1: Development Testing Payload (`assetlinks-development.json`)
Allows instant fullscreen TWA testing on local emulators/devices with the debug build:
```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.kormokari.app",
      "sha256_cert_fingerprints": [
        "0A:91:A8:C0:9D:39:81:B6:3D:56:CF:92:B7:8A:BD:F1:59:69:3A:27:02:60:9F:44:8E:A9:3A:DD:A8:F0:F3:5F"
      ]
    }
  }
]
```

#### File 2: Production Release Template (`assetlinks-production-template.json`)
For deployment by Desktop Antigravity once the release/Play Console fingerprint is established:
```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.kormokari.app",
      "sha256_cert_fingerprints": [
        "<INSERT_ACTUAL_RELEASE_OR_PLAY_APP_SIGNING_SHA256_FINGERPRINT_HERE>"
      ]
    }
  }
]
```

#### File 3: Dual Multi-App Payload (`assetlinks-production-with-legacy.json`)
Preserves backwards-compatibility for any existing `com.workdorkar.app` deployments:
```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.kormokari.app",
      "sha256_cert_fingerprints": [
        "<INSERT_ACTUAL_RELEASE_OR_PLAY_APP_SIGNING_SHA256_FINGERPRINT_HERE>"
      ]
    }
  },
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.workdorkar.app",
      "sha256_cert_fingerprints": [
        "<PRESERVE_EXISTING_WORKDORKAR_SHA256_FINGERPRINT_IF_STILL_ACTIVE>"
      ]
    }
  }
]
```

---

### 6. Client-Side Modifications Made in Phase 2

1. **`AndroidManifest.xml`**:
   * Added `<meta-data android:name="asset_statements" android:resource="@string/asset_statements" />` under `<application>` to declare the bidirectional relationship with `https://kormokari.com`.
2. **`res/values/strings.xml`**:
   * Added `asset_statements` string resource containing the formal web namespace and relation.
3. **`KormoKariConfig.kt`**:
   * Added verified `DEBUG_CERTIFICATE_SHA256` constant.
   * Documented `PRODUCTION_SIGNING_STATUS = "BLOCKED (...)"`.
   * Added `updateAssetLinksVerification(Boolean)` state callback.
4. **`KormoKariTwaLauncher.kt`**:
   * Wired `CustomTabsCallback.onRelationshipValidationResult` to observe real-time browser domain validation results.
5. **`KormoKariStartupScreen.kt`**:
   * Updated `DiagnosticsDialog` to display real-time signing identities, live domain HTTP 404 status, and TWA verification state.
6. **`ExampleRobolectricTest.kt`**:
   * Added automated test assertions for signing identity verification, blocked release status, and asset statement binding.

---

### 7. Test Results

* **Compilation:** Gradle build verified via `compile_applet` — **SUCCESS**.
* **Automated Unit & Robolectric Tests:** `gradle :app:testDebugUnitTest` — **8 passed, 0 failed, BUILD SUCCESSFUL**.
