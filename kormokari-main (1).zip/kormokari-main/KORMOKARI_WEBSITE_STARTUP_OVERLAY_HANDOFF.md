# KormoKari Website Startup Overlay & Full-Load Readiness Gate
## Implementation Package for Desktop Antigravity (Laravel / PWA / Web Client)

**Target Origin:** `https://kormokari.com/`  
**Target Android App ID:** `com.kormokari.app`  
**Architecture Context:** Trusted Web Activity (TWA) with Seamless Handover  
**Phase:** 3 — Full-Load-Gated Animated Startup Experience  

---

## 1. Problem Statement & Architecture Rationale

In Android's Trusted Web Activity (TWA) architecture, the native application code and the web engine (Google Chrome / system Custom Tabs) execute in **separate operating system processes**:

```
[Android OS Launcher]
       │
       ▼
[KormoKari Native App] (Process com.kormokari.app)
  • Shows Window Splash (`Theme.App.Starting`)
  • Runs Native Jetpack Compose Animated Splash (3 Clockwise Orbiting Dots)
  • Wires Android Browser Helper & launches TWA Intent
       │
       ▼  (Process boundary crossing)
[Host Browser Engine / Chrome] (Process com.android.chrome)
  • Receives URL https://kormokari.com/
  • Requests HTML document over network
  • Renders web document
```

If the web page does not contain an inline splash overlay matching the native Android splash screen, the user will experience a **white flash** or observe the website in an un-hydrated, partially rendered state (unloaded fonts, shifting layouts, blank content skeletons) while JavaScript bundles and initial API requests load.

### The Solution: Dual-Phase Visual Continuity
1. **Phase A (Native):** The Android app renders `KormoKariStartupScreen` immediately on launch.
2. **Phase B (Web):** The website's server response contains an **instant inline HTML/CSS overlay** visually identical to the native splash, styled inline in `<head>` and placed at the very top of `<body>`. It paints on the **first paint frame** before any JavaScript executes.
3. **Phase C (Gate):** A lightweight client-side JavaScript readiness gate holds this overlay until **all critical initialization signals** (HTML, CSS, fonts, auth session, router, and primary landing data) are completely ready.
4. **Phase D (Reveal):** The overlay fades out smoothly over 300ms, revealing an already-interactive, beautifully rendered KormoKari platform.

---

## 2. Copy-Paste Code for the Website

### Step 1: Add to `resources/views/layouts/app.blade.php` (or root `index.html`)

Insert the following code block directly inside the `<body>` tag as the **very first child element** before any other DOM elements or external `<script>` tags:

```html
<!-- ========================================================================= -->
<!-- KORMOKARI FULL-LOAD ANIMATED STARTUP OVERLAY                              -->
<!-- Matches Native Android Splash: 3 Clockwise Orbiting Dots, Soft Pink Glow   -->
<!-- ========================================================================= -->
<style id="kormokari-splash-styles">
  #kormokari-web-splash {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    height: 100dvh;
    z-index: 9999999;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: linear-gradient(180deg, #FFFFFF 0%, #FBF9FB 50%, #FFF6FA 100%);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    user-select: none;
    -webkit-user-select: none;
    overflow: hidden;
    transition: opacity 320ms cubic-bezier(0.4, 0, 0.2, 1), visibility 320ms ease;
    opacity: 1;
    visibility: visible;
  }

  #kormokari-web-splash.splash-dismissed {
    opacity: 0 !important;
    visibility: hidden !important;
    pointer-events: none !important;
  }

  .kormokari-splash-stage {
    position: relative;
    width: 300px;
    height: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  /* Soft Pink Radial Glow */
  .kormokari-radial-glow {
    position: absolute;
    width: 370px;
    height: 370px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(233, 16, 105, 0.12) 0%, rgba(233, 16, 105, 0.035) 45%, rgba(233, 16, 105, 0) 70%);
    pointer-events: none;
  }

  /* Inner Orbital Ring: 184px diameter (92px radius) */
  .kormokari-orbital-ring-inner {
    position: absolute;
    width: 184px;
    height: 184px;
    border-radius: 50%;
    border: 1.4px solid rgba(233, 16, 105, 0.17);
    box-sizing: border-box;
    pointer-events: none;
  }

  /* Outer Orbital Ring: 272px diameter (136px radius) */
  .kormokari-orbital-ring-outer {
    position: absolute;
    width: 272px;
    height: 272px;
    border-radius: 50%;
    border: 1.4px solid rgba(59, 130, 246, 0.14);
    box-sizing: border-box;
    pointer-events: none;
  }

  /* Center Logo */
  .kormokari-center-logo {
    position: relative;
    width: 122px;
    height: 122px;
    z-index: 10;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .kormokari-center-logo img,
  .kormokari-center-logo svg {
    width: 100%;
    height: 100%;
    object-fit: contain;
    filter: drop-shadow(0 6px 14px rgba(233, 16, 105, 0.12));
  }

  /* Clockwise Orbital Dot Containers (Hardware-Accelerated Rotation) */
  .kormokari-orbit-track {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    pointer-events: none;
    will-change: transform;
  }

  /* Dot 1: Brand Pink on Inner Ring (92px radius, 6.5s clockwise cycle) */
  .kormokari-track-inner-pink {
    animation: kormokariRotateClockwise 6.5s linear infinite;
  }

  .kormokari-dot-pink {
    position: absolute;
    top: -92px;
    left: -5.5px;
    width: 11px;
    height: 11px;
    border-radius: 50%;
    background-color: #E91069;
    box-shadow: 0 0 10px 4px rgba(233, 16, 105, 0.28);
  }

  /* Dot 2: Muted Grey-Lilac on Outer Ring (136px radius, 8.8s cycle, 130deg phase) */
  .kormokari-track-outer-grey {
    animation: kormokariRotateClockwise 8.8s linear infinite;
    transform: rotate(130deg);
  }

  .kormokari-dot-grey {
    position: absolute;
    top: -136px;
    left: -4.2px;
    width: 8.4px;
    height: 8.4px;
    border-radius: 50%;
    background-color: #94A3B8;
    box-shadow: 0 0 8px 3px rgba(180, 169, 196, 0.24);
  }

  /* Dot 3: Slate Blue on Outer Ring (136px radius, 8.8s cycle, 295deg phase) */
  .kormokari-track-outer-blue {
    animation: kormokariRotateClockwise 8.8s linear infinite;
    transform: rotate(295deg);
  }

  .kormokari-dot-blue {
    position: absolute;
    top: -136px;
    left: -4.8px;
    width: 9.6px;
    height: 9.6px;
    border-radius: 50%;
    background-color: #3B82F6;
    box-shadow: 0 0 9px 3.5px rgba(59, 130, 246, 0.26);
  }

  /* Brand Typography */
  .kormokari-brand-text {
    margin-top: 28px;
    text-align: center;
  }

  .kormokari-title {
    font-size: 35px;
    font-weight: 800;
    letter-spacing: -1.1px;
    line-height: 1.1;
    margin: 0;
  }

  .kormokari-title-kormo {
    color: #E91069;
  }

  .kormokari-title-kari {
    color: #111827;
  }

  .kormokari-tagline {
    margin-top: 8px;
    font-size: 14.5px;
    font-weight: 500;
    color: #64748B;
    letter-spacing: 0.1px;
    margin-bottom: 0;
  }

  /* Keyframe Animations */
  @keyframes kormokariRotateClockwise {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

  /* Reduced Motion Support */
  @media (prefers-reduced-motion: reduce) {
    .kormokari-track-inner-pink,
    .kormokari-track-outer-grey,
    .kormokari-track-outer-blue {
      animation: none !important;
    }
  }
</style>

<div id="kormokari-web-splash" aria-hidden="false" role="status" aria-label="Loading KormoKari">
  <div class="kormokari-splash-stage">
    <!-- Center Radial Glow -->
    <div class="kormokari-radial-glow"></div>

    <!-- Inner Orbital Ring -->
    <div class="kormokari-orbital-ring-inner"></div>

    <!-- Outer Orbital Ring -->
    <div class="kormokari-orbital-ring-outer"></div>

    <!-- Clockwise Orbital Dots -->
    <div class="kormokari-orbit-track kormokari-track-inner-pink">
      <div class="kormokari-dot-pink"></div>
    </div>
    <div class="kormokari-orbit-track kormokari-track-outer-grey">
      <div class="kormokari-dot-grey"></div>
    </div>
    <div class="kormokari-orbit-track kormokari-track-outer-blue">
      <div class="kormokari-dot-blue"></div>
    </div>

    <!-- Centered Connected Opportunity Logo -->
    <div class="kormokari-center-logo">
      <img src="/images/kormokari_logo.png" alt="KormoKari" onerror="this.onerror=null; this.src='/assets/logo.png';" />
    </div>
  </div>

  <!-- Wordmark & Tagline -->
  <div class="kormokari-brand-text">
    <h1 class="kormokari-title">
      <span class="kormokari-title-kormo">Kormo</span><span class="kormokari-title-kari">Kari</span>
    </h1>
    <p class="kormokari-tagline">Find work. Create opportunity.</p>
  </div>
</div>
```

---

## 3. Full-Load Readiness Gate Script (`kormokari-readiness.js`)

Include this script immediately before the closing `</body>` tag (or load as a deferred module). It manages the exact readiness signals required by Phase 3:

```javascript
/**
 * KormoKari Full-Load Readiness Gate
 * Verifies all 7 critical startup signals before fading out the splash overlay.
 */
(function() {
  const SPLASH_ID = 'kormokari-web-splash';
  const MAX_STARTUP_TIMEOUT_MS = 10000; // 10s maximum bounded safety threshold
  const MINIMUM_DISPLAY_TIME_MS = 350;  // Prevents microscopic flash if cached

  const startTime = performance.now();
  let isGateDismissed = false;

  // Signal state flags
  const readiness = {
    domContentLoaded: false,
    fontsLoaded: false,
    routerReady: false,
    authResolved: false,
    criticalDataLoaded: false,
    interactiveIdle: false
  };

  function dismissSplash() {
    if (isGateDismissed) return;
    isGateDismissed = true;

    const overlay = document.getElementById(SPLASH_ID);
    if (!overlay) return;

    overlay.classList.add('splash-dismissed');
    overlay.setAttribute('aria-hidden', 'true');

    // Notify listeners / native layers if needed
    window.dispatchEvent(new CustomEvent('kormokari:startup-ready', {
      detail: { durationMs: performance.now() - startTime }
    }));

    // Clean up DOM after transition completes
    setTimeout(() => {
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
      const styles = document.getElementById('kormokari-splash-styles');
      if (styles && styles.parentNode) {
        styles.parentNode.removeChild(styles);
      }
    }, 400);
  }

  function checkReadiness() {
    if (isGateDismissed) return;

    const allSignalsReady = (
      readiness.domContentLoaded &&
      readiness.fontsLoaded &&
      readiness.routerReady &&
      readiness.authResolved &&
      readiness.criticalDataLoaded &&
      readiness.interactiveIdle
    );

    if (allSignalsReady) {
      const elapsed = performance.now() - startTime;
      const remainingDelay = Math.max(0, MINIMUM_DISPLAY_TIME_MS - elapsed);
      setTimeout(dismissSplash, remainingDelay);
    }
  }

  // --- SIGNAL 1: DOM Ready ---
  if (document.readyState === 'interactive' || document.readyState === 'complete') {
    readiness.domContentLoaded = true;
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      readiness.domContentLoaded = true;
      checkReadiness();
    });
  }

  // --- SIGNAL 2: Web Fonts Loaded ---
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => {
      readiness.fontsLoaded = true;
      checkReadiness();
    }).catch(() => {
      // Degrade gracefully if font network fails
      readiness.fontsLoaded = true;
      checkReadiness();
    });
  } else {
    readiness.fontsLoaded = true;
  }

  // --- SIGNAL 3 & 4 & 5: Router, Auth, and Critical Data Signals ---
  // If your website uses Inertia.js, Vue, React, or standard Laravel Blade:
  window.KormoKariGateway = {
    setRouterReady: function() {
      readiness.routerReady = true;
      checkReadiness();
    },
    setAuthResolved: function() {
      readiness.authResolved = true;
      checkReadiness();
    },
    setCriticalDataLoaded: function() {
      readiness.criticalDataLoaded = true;
      checkReadiness();
    },
    signalAllReady: function() {
      readiness.routerReady = true;
      readiness.authResolved = true;
      readiness.criticalDataLoaded = true;
      checkReadiness();
    }
  };

  // Default automatic signal fallback for non-SPA Blade views:
  // If no SPA framework signals within 1200ms after window load, infer standard SSR completion
  window.addEventListener('load', () => {
    readiness.domContentLoaded = true;
    setTimeout(() => {
      if (!readiness.routerReady) readiness.routerReady = true;
      if (!readiness.authResolved) readiness.authResolved = true;
      if (!readiness.criticalDataLoaded) readiness.criticalDataLoaded = true;
      checkReadiness();
    }, 400);
  });

  // --- SIGNAL 6: Page Interactivity (Main Thread Idle) ---
  if ('requestIdleCallback' in window) {
    window.requestIdleCallback(() => {
      requestAnimationFrame(() => {
        readiness.interactiveIdle = true;
        checkReadiness();
      });
    }, { timeout: 3000 });
  } else {
    setTimeout(() => {
      requestAnimationFrame(() => {
        readiness.interactiveIdle = true;
        checkReadiness();
      });
    }, 500);
  }

  // --- SAFETY TIMEOUT: Bounded threshold to prevent stuck screens ---
  setTimeout(() => {
    if (!isGateDismissed) {
      console.warn('[KormoKari] Startup readiness gate hit safety threshold. Forcing reveal.');
      dismissSplash();
    }
  }, MAX_STARTUP_TIMEOUT_MS);

})();
```

---

## 4. Integration with Frontend Frameworks

* **Vue 3 / Inertia.js:**
  ```javascript
  // In app.js
  createInertiaApp({
    setup({ el, App, props, plugin }) {
      createApp({ render: () => h(App, props) })
        .use(plugin)
        .mount(el);
      
      // Signal gateway that SPA mounted and auth is resolved
      window.KormoKariGateway?.signalAllReady();
    }
  });
  ```

* **Livewire / Alpine.js:**
  ```javascript
  document.addEventListener('livewire:navigated', () => {
    window.KormoKariGateway?.signalAllReady();
  });
  ```

---

## 5. Pull-To-Refresh Architecture for TWA & PWA

In Trusted Web Activities (TWA) powered by Chrome/Chromium, **pull-to-refresh** operates across both the native Android container and the web layer:

### A. How Chrome Handles Pull-to-Refresh in TWA
* Chromium contains built-in native overscroll pull-to-refresh that triggers when the viewport is at `window.scrollY === 0` and the user drags down.
* **CRITICAL CSS REQUIREMENT:** Ensure your CSS on `html` and `body` does NOT disable overscroll:
  ```css
  /* ALLOW Chromium native pull-to-refresh gesture in TWA */
  html, body {
    overscroll-behavior-y: auto; /* DO NOT set to 'none' or 'contain' on the main page */
  }
  ```
* If your application uses a full-height fixed shell (`height: 100vh; overflow: hidden;`) with an inner scrolling container (e.g. `<main id="app-content" style="overflow-y: auto;">`), Chromium cannot detect that the page is at the top unless overscroll is propagated or a lightweight touch listener is used.

### B. Ready-to-Use JavaScript Pull-to-Refresh for PWA
If your PWA uses internal container scrolling, add this lightweight pull-to-refresh snippet to `resources/js/pull-to-refresh.js`:

```javascript
/**
 * KormoKari PWA Pull-to-Refresh Component
 * Triggers clean reload with service worker cache bypass when pulled at top.
 */
(function() {
  let touchStartY = 0;
  let touchMoveY = 0;
  let isPulling = false;
  const THRESHOLD_PX = 90;

  window.addEventListener('touchstart', (e) => {
    if (window.scrollY === 0 && e.touches.length === 1) {
      touchStartY = e.touches[0].clientY;
      isPulling = true;
    }
  }, { passive: true });

  window.addEventListener('touchmove', (e) => {
    if (!isPulling) return;
    touchMoveY = e.touches[0].clientY;
    const distance = touchMoveY - touchStartY;
    if (distance > 0 && window.scrollY === 0) {
      // Optional: Update custom pull indicator
    }
  }, { passive: true });

  window.addEventListener('touchend', (e) => {
    if (!isPulling) return;
    const distance = touchMoveY - touchStartY;
    if (distance > THRESHOLD_PX && window.scrollY === 0) {
      // User pulled past threshold: reload PWA
      if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({ type: 'PURGE_CACHE' });
      }
      window.location.reload();
    }
    isPulling = false;
    touchStartY = 0;
    touchMoveY = 0;
  }, { passive: true });
})();
```

---

## 6. Verification Checklist for Desktop Antigravity

1. **Verify AssetLinks:** Confirm `https://kormokari.com/.well-known/assetlinks.json` serves the package `com.kormokari.app` with fingerprint `0A:91:A8:C0:9D:39:81:B6:3D:56:CF:92:B7:8A:BD:F1:59:69:3A:27:02:60:9F:44:8E:A9:3A:DD:A8:F0:F3:5F`.
2. **Verify Zero White Flash:** Open Chrome on Android, visit `https://kormokari.com/`. Verify that the page immediately paints the soft pink gradient with orbiting dots without a flash of white.
3. **Verify Fade Out:** Confirm the overlay fades out smoothly once critical data is loaded, without sudden UI shifts or un-hydrated jumps.
4. **Verify Pull-to-Refresh:** At the top of any page, drag down. Confirm the refresh indicator appears and reloads the current route/view.

