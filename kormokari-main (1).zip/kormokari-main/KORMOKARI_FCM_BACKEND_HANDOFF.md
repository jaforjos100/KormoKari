# KormoKari Firebase Cloud Messaging (FCM) Integration & Server Handoff
## Backend & API Guide for Job Updates & Application Status Alerts

**Android Application ID:** `com.kormokari.app`  
**Production Origin:** `https://kormokari.com/`  
**FCM Service in App:** `com.example.fcm.KormoKariFirebaseMessagingService`  
**Target Platform:** Android (TWA Container + Native Push Dispatcher)

---

## 1. Overview & Architecture

The KormoKari Android app receives real-time push notifications from Firebase Cloud Messaging even when the app is closed or running in the background. When a user taps a notification, the app opens directly to the relevant job opportunity or application screen inside the verified Trusted Web Activity (TWA) without showing an unauthenticated white screen.

```
[KormoKari Backend (Laravel / Node)]
                 │
                 ▼ (Firebase Admin SDK / HTTP v1)
      [Firebase Cloud Messaging]
                 │
                 ▼ (Google Play Services Push Stream)
     [KormoKari Android Device]
  • KormoKariFirebaseMessagingService receives payload
  • Builds rich Notification with KormoKari brand styling (#E91069)
  • Routes to appropriate notification channel
                 │
                 ▼ User taps notification
      [Deep Linked TWA Launch]
  • Directly navigates to https://kormokari.com/jobs/{id}
```

---

## 2. Notification Channels Configured in the Android App

The app automatically registers two dedicated notification channels with distinct priorities and vibration patterns:

| Channel ID | Channel Name | Importance | Use Case |
| :--- | :--- | :--- | :--- |
| `kormokari_job_alerts` | **Job Updates & Opportunities** | `IMPORTANCE_HIGH` (Sound, Heads-up banner, Vibration) | New job postings matching user skills, urgent hiring alerts |
| `kormokari_app_status` | **Application & Account Alerts** | `IMPORTANCE_DEFAULT` (Sound, Notification Shade) | Application shortlisted, interview scheduled, employer feedback |

---

## 3. FCM Payload Specifications (HTTP v1 API)

### Scenario A: New Job Match Alert
Sends a high-priority alert that deep-links directly to the job details page.

**Endpoint:** `POST https://fcm.googleapis.com/v1/projects/{your-firebase-project-id}/messages:send`

```json
{
  "message": {
    "token": "USER_FCM_REGISTRATION_TOKEN",
    "notification": {
      "title": "New Job Match: Electrician in Gulshan",
      "body": "A top-rated client just posted a job matching your skills. Tap to view and apply."
    },
    "data": {
      "channel": "kormokari_job_alerts",
      "job_id": "8492",
      "url": "https://kormokari.com/jobs/8492"
    },
    "android": {
      "priority": "high",
      "notification": {
        "channel_id": "kormokari_job_alerts",
        "icon": "kormokari_splash_icon",
        "color": "#E91069",
        "click_action": "OPEN_JOB_ACTION"
      }
    }
  }
}
```

### Scenario B: Application Status Update
Notifies a candidate that their application status has changed (e.g., Shortlisted, Interview Scheduled).

```json
{
  "message": {
    "token": "USER_FCM_REGISTRATION_TOKEN",
    "notification": {
      "title": "Application Status: Shortlisted! 🎉",
      "body": "Your application for Senior Plumber at Apex Logistics was shortlisted."
    },
    "data": {
      "channel": "kormokari_app_status",
      "application_id": "1049",
      "url": "https://kormokari.com/dashboard/applications/1049"
    },
    "android": {
      "priority": "normal",
      "notification": {
        "channel_id": "kormokari_app_status",
        "icon": "kormokari_splash_icon",
        "color": "#E91069"
      }
    }
  }
}
```

---

## 4. Backend Implementation Example (PHP / Laravel)

If KormoKari uses Laravel with `kreait/laravel-firebase` or standard HTTP client:

```php
namespace App\Services;

use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;

class KormoKariPushNotificationService
{
    protected $messaging;

    public function __construct()
    {
        $factory = (new Factory)->withServiceAccount(config('firebase.credentials'));
        $this->messaging = $factory->createMessaging();
    }

    /**
     * Send instant job match alert.
     */
    public function sendJobAlert(string $fcmToken, string $jobTitle, int $jobId, string $location): void
    {
        $message = CloudMessage::withTarget('token', $fcmToken)
            ->withNotification(Notification::create(
                "New Job Match: {$jobTitle}",
                "Job opportunity available in {$location}. Tap to apply."
            ))
            ->withData([
                'channel' => 'kormokari_job_alerts',
                'job_id' => (string) $jobId,
                'url' => "https://kormokari.com/jobs/{$jobId}"
            ]);

        $this->messaging->send($message);
    }

    /**
     * Send application status change notification.
     */
    public function sendApplicationStatusAlert(string $fcmToken, string $company, string $status, int $applicationId): void
    {
        $message = CloudMessage::withTarget('token', $fcmToken)
            ->withNotification(Notification::create(
                "Application Update: {$status}",
                "Your application at {$company} has been marked as {$status}."
            ))
            ->withData([
                'channel' => 'kormokari_app_status',
                'application_id' => (string) $applicationId,
                'url' => "https://kormokari.com/dashboard/applications/{$applicationId}"
            ]);

        $this->messaging->send($message);
    }
}
```

---

## 5. Token Synchronization Flow

1. When the Android app starts, `FcmTokenManager` retrieves the device's unique FCM registration token.
2. The website can provide an endpoint `POST /api/v1/users/device-token` accepting `{ "fcm_token": "...", "platform": "android" }`.
3. The token is associated with the authenticated user session so targeted alerts reach the correct worker or employer.
