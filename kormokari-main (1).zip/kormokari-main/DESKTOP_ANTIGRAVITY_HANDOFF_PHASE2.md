# KormoKari Android — Phase 2 Live Server Deployment Handoff
## Desktop Antigravity Handoff Guide for Digital Asset Links & TWA Fullscreen Verification

**Target Domain:** `https://kormokari.com/`  
**Endpoint Required:** `https://kormokari.com/.well-known/assetlinks.json`  
**Application ID:** `com.kormokari.app`  

---

### 1. Live Domain Status Audit
On October 28, 2026, an automated audit of the live production domain was performed:
* **Request:** `GET https://kormokari.com/.well-known/assetlinks.json`
* **Response Status:** `HTTP/2 404 Not Found` (Served via Cloudflare)
* **Finding:** No Digital Asset Links file is currently deployed at `https://kormokari.com/.well-known/assetlinks.json`.

---

### 2. Signing Identity Audit & Verification

#### Development / Debug Build (Active in AI Studio)
* **Application ID:** `com.kormokari.app`
* **Keystore:** `debug.keystore`
* **Alias:** `androiddebugkey`
* **Verified SHA-256 Fingerprint:**
  `0A:91:A8:C0:9D:39:81:B6:3D:56:CF:92:B7:8A:BD:F1:59:69:3A:27:02:60:9F:44:8E:A9:3A:DD:A8:F0:F3:5F`
* **Suitability:** Valid for development and testing on emulators and debug-installed hardware.

#### Production Release Build (Distribution)
* **Status:** `BLOCKED` (Pending production release keystore or Google Play App Signing key generation).
* **Rule:** In strict accordance with security mandates, **no fake or guessed SHA-256 fingerprint was generated.**

---

### 3. Distribution Strategy & Fingerprint Extraction

#### Path A: Google Play Store (Google Play App Signing)
If distributing through Google Play Console:
1. Google Play re-signs the APK delivered to end users using the **App Signing key**, while your local keystore acts as the **Upload key**.
2. To obtain the correct production fingerprint:
   * Go to **Google Play Console** -> Select `KormoKari` (`com.kormokari.app`).
   * Navigate to **Release** -> **Setup** -> **App Integrity** -> **App Signing tab**.
   * Copy the **SHA-256 certificate fingerprint** under the **App signing key certificate** section.
3. Paste that fingerprint into `assetlinks.json`. *(Do not use the Upload Key fingerprint).*

#### Path B: Direct APK Distribution (In-House / Web Download)
If distributing the release APK directly without Google Play:
1. Locate your release keystore `my-upload-key.jks` or release key.
2. Run:
   ```bash
   keytool -list -v -keystore my-upload-key.jks -alias upload
   ```
3. Copy the `SHA256: ...` fingerprint and insert it into `assetlinks.json`.

---

### 4. Deploying to the Production Web Server (`kormokari.com`)

1. In the Laravel web root (typically `public/` directory), create the directory `.well-known/` if it does not already exist:
   ```bash
   mkdir -p public/.well-known
   ```
2. Place the file `assetlinks.json` inside `public/.well-known/assetlinks.json`.
3. Ensure web server permissions are readable (`chmod 644 public/.well-known/assetlinks.json`).
4. **Web Server / Nginx Configuration**: Ensure Nginx / Apache serves `.well-known` with `application/json` and does not block dotfiles:
   ```nginx
   location ^~ /.well-known/ {
       allow all;
       default_type application/json;
   }
   ```
5. **Cloudflare Cache Flush**: If using Cloudflare proxying, purge cache for `https://kormokari.com/.well-known/assetlinks.json` after upload.

---

### 5. Verification Test Commands

Once published, verify the endpoint returns HTTP 200 and valid JSON:
```bash
curl -i https://kormokari.com/.well-known/assetlinks.json
```

Verify using Google's Digital Asset Links API:
```bash
curl "https://digitalassetlinks.googleapis.com/v1/statements:list?source.web.site=https://kormokari.com&relation=delegate_permission/common.handle_all_urls"
```

When verified:
* Launching `KormoKari` on Android with Chrome installed will open `https://kormokari.com/` in true **fullscreen TWA mode without any browser URL bar or toolbar controls**.
